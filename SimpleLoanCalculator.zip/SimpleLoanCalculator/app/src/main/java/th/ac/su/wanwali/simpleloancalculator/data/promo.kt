package th.ac.su.wanwali.simpleloancalculator.data

data class  promo(
    val promo_name: String,
    val promo_description: String,
    val promo_code: Int,
    val imageFile: String,
)