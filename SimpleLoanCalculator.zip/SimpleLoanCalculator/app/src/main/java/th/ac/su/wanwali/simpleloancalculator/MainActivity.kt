package th.ac.su.wanwali.simpleloancalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import th.ac.su.wanwali.simpleloancalculator.data.promo
import th.ac.su.wanwali.simpleloancalculator.utills.getJsonDataFromAsset

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val jsonFileString = getJsonDataFromAsset
                (applicationContext, fileName: "promotion.json" )

        //Log.i(tag: "data", jsonFileString)

        val gson = Gson()
        val listItemType = object :TypeToken<ArrayList<promo>>(){}.type

        var promoList : ArrayList<promo> = gson.fromJson(jsonFileString,listItemType)

        Log.i(tag: "data", promoList[0].promo_name)
    }

}